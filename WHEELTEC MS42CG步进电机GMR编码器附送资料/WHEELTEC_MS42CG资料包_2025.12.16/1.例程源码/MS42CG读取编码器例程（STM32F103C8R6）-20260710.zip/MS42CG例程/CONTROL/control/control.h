#ifndef _CONTROL_H
#define _CONTROL_H
#include "sys.h"
#define ABS(x)  ((x)>0?(x):-(x))
float Get_motor_speed(void);

#endif
