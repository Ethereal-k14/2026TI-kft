#include "control.h"
float Last_Machinery_Angle;
u8 first_c;
void TIM1_UP_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM1,TIM_IT_Update)!=RESET) 
	{
		TIM_ClearITPendingBit(TIM1,TIM_IT_Update);
		#if AB_Encoder
		Encoder_pr=Read_Encoder();
		Speed = Encoder_pr*100/4000.0*60;//���ת�٣���λRPM	
        Mechanical_Angle = Get_Position(10);
		#elif SPI_Encoder
        Mechanical_Angle = Get_Machinery_Angle();
		Speed = Get_motor_speed();
		#endif
	}
}

int EXTI15_10_IRQHandler(void) 
{    
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)==1)		
	{
		EXTI->PR=1<<12;    
        Z_Count++;	
	}
}

float Get_motor_speed(void)
{
	float speed_printf;
	float d_angle,s_angle;
	 d_angle = Mechanical_Angle -Last_Machinery_Angle;
	 Last_Machinery_Angle = Mechanical_Angle;
	 s_angle = d_angle;
	 if(s_angle>180) s_angle = s_angle - 360;
	 else if(s_angle<-180) s_angle =s_angle+360;
	 if(first_c<5)
	 {
		 first_c++;
	 }
	 else
	 {
		 first_c = 6;
		 speed_printf = s_angle/360*100*6.2831856;
	 }
	 return speed_printf;
}