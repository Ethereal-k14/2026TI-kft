/***********************************************
��˾����Ȥ�Ƽ�(��ݸ)���޹�˾
Ʒ�ƣ�WHEELTEC
������wheeltec.net
�Ա����̣�shop114407458.taobao.com 
����ͨ: https://minibalance.aliexpress.com/store/4455017
�汾��V1.0
�޸�ʱ�䣺2022-09-01

Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com 
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version: V1.0
Update��2022-09-01

All rights reserved
***********************************************/
#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 
#define RECEIVE_DATA_SIZE 11             //���յ������С
#define FRAME_HEADER      0X7B          //֡ͷ
#define FRAME_tail        0X7D          //֡β
typedef struct _RECEIVE_DARA_
{
	u8 buffer[RECEIVE_DATA_SIZE];
	unsigned char PC_buffer[12];
}RECEIVE_DATA;
extern u8 Send_Data[12];

void uart_init(u32 bound);
void usart1_send(u8 data);
u8 CRC_Sum(unsigned char Count_Number);
float Speed_transition(u8 High,u8 Low);
u32 Position_transition(u8 High,u8 Low);
float SPeed_transition(u8 High,u8 Low);
float Angle_transition(u8 High,u8 Low);
float Baud_transition(u8 High,u8 middle,u8 Low);
void uart3_init(u32 bound);
void data_transition(void);
void USART1_SEND(void);
u8 CRC_Sum1(unsigned char Count_Number);
#endif


