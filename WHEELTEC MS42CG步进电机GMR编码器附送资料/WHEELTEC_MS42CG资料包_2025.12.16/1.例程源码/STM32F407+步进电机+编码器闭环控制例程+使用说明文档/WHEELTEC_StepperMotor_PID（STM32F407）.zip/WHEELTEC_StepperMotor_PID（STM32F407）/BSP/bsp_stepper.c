/**
  ******************************************************************************
  * @file    bsp_stepper.c
  * @brief   D36A 步进驱动器脉冲输出驱动的实现
  ******************************************************************************
  * 本文件移植自 WHEELTEC 云台工程中已验证的 bsp_d36a_stepper.c。
  * 详细原理说明见 bsp_stepper.h 的文件头注释。
  ******************************************************************************
  */
#include "bsp_stepper.h"
#include "tim.h"

#define STEPPER_AXIS_COUNT              2U
/* 最小翻转间隔 10 个计数(=100us)，防止频率太高导致中断来不及处理 */
#define STEPPER_MIN_TOGGLE_INTERVAL    10U

/* 每个轴的运行状态。volatile 是因为这些变量会在中断里被修改 */
typedef struct
{
    volatile uint32_t remaining_toggles; /* 剩余翻转次数（1步=2次翻转） */
    volatile uint16_t toggle_interval;   /* 相邻两次翻转的计数间隔（决定频率） */
    volatile uint8_t  busy;              /* 1=正在发脉冲 */
    volatile GPIO_PinState direction;    /* 当前方向电平 */
} StepperState_t;

static StepperState_t s_axis[STEPPER_AXIS_COUNT];

/*
 * 进入/退出临界区：主循环和中断都会访问 s_axis，
 * 修改时必须先关总中断，防止改到一半被中断打断造成数据错乱。
 */
static uint32_t Stepper_EnterCritical(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    return primask;
}

static void Stepper_ExitCritical(uint32_t primask)
{
    if (primask == 0U)
    {
        __enable_irq(); /* 只有进入前中断是开着的才重新打开 */
    }
}

static uint8_t Stepper_IsValidAxis(StepperAxis_t axis)
{
    return ((axis == STEPPER_AXIS_1) ||
            (axis == STEPPER_AXIS_2)) ? 1U : 0U;
}

/*
 * 设置输出比较模式：
 *   TIM_OCMODE_TOGGLE          -> 计数值追上CCR时引脚自动翻转（发脉冲用）
 *   TIM_OCMODE_FORCED_INACTIVE -> 强制输出低电平（停止时用，保证STEP停在低）
 */
static void Stepper_SetOutputMode(StepperAxis_t axis, uint32_t mode)
{
    if (axis == STEPPER_AXIS_1)
    {
        MODIFY_REG(TIM8->CCMR1, TIM_CCMR1_OC1M, mode);
    }
    else
    {
        MODIFY_REG(TIM8->CCMR1, TIM_CCMR1_OC2M, mode << 8U);
    }
}

/* 关闭该轴的比较中断并清除中断标志 */
static void Stepper_DisableChannelInterrupt(StepperAxis_t axis)
{
    if (axis == STEPPER_AXIS_1)
    {
        CLEAR_BIT(TIM8->DIER, TIM_DIER_CC1IE);
        TIM8->SR = ~TIM_SR_CC1IF;
    }
    else
    {
        CLEAR_BIT(TIM8->DIER, TIM_DIER_CC2IE);
        TIM8->SR = ~TIM_SR_CC2IF;
    }
}

/* 停止一个轴（内部版本，调用前必须已在临界区内） */
static void Stepper_StopUnsafe(StepperAxis_t axis)
{
    Stepper_DisableChannelInterrupt(axis);
    Stepper_SetOutputMode(axis, TIM_OCMODE_FORCED_INACTIVE);
    s_axis[axis].remaining_toggles = 0U;
    s_axis[axis].busy = 0U;

    /* 两个轴都停了才关定时器，省电且计数器不再空转 */
    if ((s_axis[STEPPER_AXIS_1].busy == 0U) &&
        (s_axis[STEPPER_AXIS_2].busy == 0U))
    {
        CLEAR_BIT(TIM8->CR1, TIM_CR1_CEN);
    }
}

void Stepper_Init(void)
{
    uint32_t primask = Stepper_EnterCritical();

    /* 先确保定时器停止、两路比较中断关闭 */
    CLEAR_BIT(TIM8->CR1, TIM_CR1_CEN);
    CLEAR_BIT(TIM8->DIER, TIM_DIER_CC1IE | TIM_DIER_CC2IE);

    /* 两路输出强制为低电平（STEP空闲时必须是低） */
    Stepper_SetOutputMode(STEPPER_AXIS_1, TIM_OCMODE_FORCED_INACTIVE);
    Stepper_SetOutputMode(STEPPER_AXIS_2, TIM_OCMODE_FORCED_INACTIVE);

    /* 使能两路比较输出。TIM8是高级定时器，还必须置位主输出使能MOE */
    SET_BIT(TIM8->CCER, TIM_CCER_CC1E | TIM_CCER_CC2E);
    SET_BIT(TIM8->BDTR, TIM_BDTR_MOE);

    /* DIR 引脚输出低电平作为初始方向 */
    HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(DIR2_GPIO_Port, DIR2_Pin, GPIO_PIN_RESET);

    s_axis[STEPPER_AXIS_1].remaining_toggles = 0U;
    s_axis[STEPPER_AXIS_1].toggle_interval = 0U;
    s_axis[STEPPER_AXIS_1].busy = 0U;
    s_axis[STEPPER_AXIS_1].direction = GPIO_PIN_RESET;
    s_axis[STEPPER_AXIS_2].remaining_toggles = 0U;
    s_axis[STEPPER_AXIS_2].toggle_interval = 0U;
    s_axis[STEPPER_AXIS_2].busy = 0U;
    s_axis[STEPPER_AXIS_2].direction = GPIO_PIN_RESET;

    TIM8->SR = 0U; /* 清除所有中断标志 */

    /* 使能 TIM8 比较中断（优先级设高一点，保证脉冲节拍准） */
    HAL_NVIC_SetPriority(TIM8_CC_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(TIM8_CC_IRQn);

    Stepper_ExitCritical(primask);
}

HAL_StatusTypeDef Stepper_SetDirection(StepperAxis_t axis,
                                       GPIO_PinState direction)
{
    uint32_t primask;

    if ((Stepper_IsValidAxis(axis) == 0U) ||
        ((direction != GPIO_PIN_RESET) && (direction != GPIO_PIN_SET)))
    {
        return HAL_ERROR;
    }

    primask = Stepper_EnterCritical();

    /* 运行中不允许换向：脉冲发到一半换向会造成丢步 */
    if (s_axis[axis].busy != 0U)
    {
        Stepper_ExitCritical(primask);
        return HAL_BUSY;
    }

    if (axis == STEPPER_AXIS_1)
    {
        HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, direction);
    }
    else
    {
        HAL_GPIO_WritePin(DIR2_GPIO_Port, DIR2_Pin, direction);
    }

    s_axis[axis].direction = direction;
    Stepper_ExitCritical(primask);
    return HAL_OK;
}

GPIO_PinState Stepper_GetDirection(StepperAxis_t axis)
{
    if (Stepper_IsValidAxis(axis) == 0U)
    {
        return GPIO_PIN_RESET;
    }

    return s_axis[axis].direction;
}

HAL_StatusTypeDef Stepper_Start(StepperAxis_t axis,
                                uint32_t steps,
                                uint32_t frequency_hz)
{
    uint32_t denominator;
    uint32_t interval;
    uint32_t primask;

    if (Stepper_IsValidAxis(axis) == 0U)
    {
        return HAL_ERROR;
    }

    if (steps == 0U)
    {
        Stepper_Stop(axis);
        return HAL_OK;
    }

    if ((frequency_hz < STEPPER_MIN_FREQ_HZ) ||
        (frequency_hz > STEPPER_MAX_FREQ_HZ) ||
        (steps > (UINT32_MAX / 2U)))
    {
        return HAL_ERROR;
    }

    /*
     * 计算翻转间隔：
     * 1个脉冲 = 高电平+低电平 = 2次翻转，所以翻转频率 = 2*脉冲频率，
     * 间隔 = 计数频率 / (2*脉冲频率)。加 denominator/2 是四舍五入。
     */
    denominator = frequency_hz * 2U;
    interval = (STEPPER_TIMER_TICK_HZ + (denominator / 2U)) / denominator;

    if ((interval < STEPPER_MIN_TOGGLE_INTERVAL) ||
        (interval > UINT16_MAX))
    {
        return HAL_ERROR;
    }

    primask = Stepper_EnterCritical();

    if (s_axis[axis].busy != 0U)
    {
        Stepper_ExitCritical(primask);
        return HAL_BUSY; /* 上一段脉冲还没发完 */
    }

    Stepper_DisableChannelInterrupt(axis);
    Stepper_SetOutputMode(axis, TIM_OCMODE_FORCED_INACTIVE);

    s_axis[axis].toggle_interval = (uint16_t)interval;
    s_axis[axis].remaining_toggles = steps * 2U;
    s_axis[axis].busy = 1U;

    /*
     * 把 CCR 设到"当前计数值+一个间隔"处，然后切到翻转模式并开中断。
     * 计数值追上 CCR 时输出第一次翻转（STEP变高），中断里继续推进。
     */
    if (axis == STEPPER_AXIS_1)
    {
        TIM8->CCR1 = (uint16_t)(TIM8->CNT + interval);
        TIM8->SR = ~TIM_SR_CC1IF;
        Stepper_SetOutputMode(axis, TIM_OCMODE_TOGGLE);
        SET_BIT(TIM8->CCER, TIM_CCER_CC1E);
        SET_BIT(TIM8->DIER, TIM_DIER_CC1IE);
    }
    else
    {
        TIM8->CCR2 = (uint16_t)(TIM8->CNT + interval);
        TIM8->SR = ~TIM_SR_CC2IF;
        Stepper_SetOutputMode(axis, TIM_OCMODE_TOGGLE);
        SET_BIT(TIM8->CCER, TIM_CCER_CC2E);
        SET_BIT(TIM8->DIER, TIM_DIER_CC2IE);
    }

    SET_BIT(TIM8->BDTR, TIM_BDTR_MOE);
    SET_BIT(TIM8->CR1, TIM_CR1_CEN); /* 启动定时器 */

    Stepper_ExitCritical(primask);
    return HAL_OK;
}

HAL_StatusTypeDef Stepper_Feed(StepperAxis_t axis,
                               uint32_t steps,
                               uint32_t frequency_hz)
{
    uint32_t denominator;
    uint32_t interval;
    uint32_t primask;

    if (Stepper_IsValidAxis(axis) == 0U)
    {
        return HAL_ERROR;
    }

    if (steps == 0U)
    {
        return HAL_OK;
    }

    if ((frequency_hz < STEPPER_MIN_FREQ_HZ) ||
        (frequency_hz > STEPPER_MAX_FREQ_HZ) ||
        (steps > (UINT32_MAX / 4U)))
    {
        return HAL_ERROR;
    }

    denominator = frequency_hz * 2U;
    interval = (STEPPER_TIMER_TICK_HZ + (denominator / 2U)) / denominator;

    if ((interval < STEPPER_MIN_TOGGLE_INTERVAL) ||
        (interval > UINT16_MAX))
    {
        return HAL_ERROR;
    }

    primask = Stepper_EnterCritical();

    if (s_axis[axis].busy != 0U)
    {
        /*
         * 该轴还在发脉冲：直接把翻转次数加上去（每步2次，加偶数次
         * 保证脉冲串结束时STEP仍停在低电平），新频率从下一次翻转生效。
         * 这样新旧两段脉冲之间没有任何间隙。
         */
        s_axis[axis].remaining_toggles += steps * 2U;
        s_axis[axis].toggle_interval = (uint16_t)interval;
        Stepper_ExitCritical(primask);
        return HAL_OK;
    }

    Stepper_ExitCritical(primask);
    /* 该轴已停：按普通方式启动一段新脉冲 */
    return Stepper_Start(axis, steps, frequency_hz);
}

void Stepper_Stop(StepperAxis_t axis)
{
    uint32_t primask;

    if (Stepper_IsValidAxis(axis) == 0U)
    {
        return;
    }

    primask = Stepper_EnterCritical();
    Stepper_StopUnsafe(axis);
    Stepper_ExitCritical(primask);
}

void Stepper_StopAll(void)
{
    uint32_t primask = Stepper_EnterCritical();
    Stepper_StopUnsafe(STEPPER_AXIS_1);
    Stepper_StopUnsafe(STEPPER_AXIS_2);
    Stepper_ExitCritical(primask);
}

uint8_t Stepper_IsBusy(StepperAxis_t axis)
{
    if (Stepper_IsValidAxis(axis) == 0U)
    {
        return 0U;
    }

    return s_axis[axis].busy;
}

uint32_t Stepper_GetRemainingSteps(StepperAxis_t axis)
{
    uint32_t toggles;

    if (Stepper_IsValidAxis(axis) == 0U)
    {
        return 0U;
    }

    toggles = s_axis[axis].remaining_toggles;
    return (toggles + 1U) / 2U;
}

/**
  * TIM8 比较中断处理：每次引脚翻转后进入这里。
  * 工作：翻转次数减一 -> 没发完就把CCR往后推一个间隔 -> 发完就停该轴。
  * 本函数由 stm32f4xx_it.c 中的 TIM8_CC_IRQHandler() 调用。
  */
void Stepper_TIM8_CC_IRQHandler(void)
{
    uint32_t status = TIM8->SR;
    uint32_t interrupt_enable = TIM8->DIER;

    /* ---------- 轴1（通道1） ---------- */
    if (((status & TIM_SR_CC1IF) != 0U) &&
        ((interrupt_enable & TIM_DIER_CC1IE) != 0U))
    {
        TIM8->SR = ~TIM_SR_CC1IF; /* 清中断标志 */

        if (s_axis[STEPPER_AXIS_1].remaining_toggles > 0U)
        {
            s_axis[STEPPER_AXIS_1].remaining_toggles--;
        }

        if (s_axis[STEPPER_AXIS_1].remaining_toggles == 0U)
        {
            Stepper_StopUnsafe(STEPPER_AXIS_1); /* 发完了，自动停 */
        }
        else
        {
            /* 把下一次翻转点往后推一个间隔（16位自然回绕，无需特殊处理） */
            TIM8->CCR1 = (uint16_t)(TIM8->CCR1 +
                             s_axis[STEPPER_AXIS_1].toggle_interval);
        }
    }

    /* ---------- 轴2（通道2） ---------- */
    if (((status & TIM_SR_CC2IF) != 0U) &&
        ((interrupt_enable & TIM_DIER_CC2IE) != 0U))
    {
        TIM8->SR = ~TIM_SR_CC2IF;

        if (s_axis[STEPPER_AXIS_2].remaining_toggles > 0U)
        {
            s_axis[STEPPER_AXIS_2].remaining_toggles--;
        }

        if (s_axis[STEPPER_AXIS_2].remaining_toggles == 0U)
        {
            Stepper_StopUnsafe(STEPPER_AXIS_2);
        }
        else
        {
            TIM8->CCR2 = (uint16_t)(TIM8->CCR2 +
                             s_axis[STEPPER_AXIS_2].toggle_interval);
        }
    }

    /* 两轴都空闲时关掉定时器 */
    if ((s_axis[STEPPER_AXIS_1].busy == 0U) &&
        (s_axis[STEPPER_AXIS_2].busy == 0U))
    {
        CLEAR_BIT(TIM8->CR1, TIM_CR1_CEN);
    }
}
