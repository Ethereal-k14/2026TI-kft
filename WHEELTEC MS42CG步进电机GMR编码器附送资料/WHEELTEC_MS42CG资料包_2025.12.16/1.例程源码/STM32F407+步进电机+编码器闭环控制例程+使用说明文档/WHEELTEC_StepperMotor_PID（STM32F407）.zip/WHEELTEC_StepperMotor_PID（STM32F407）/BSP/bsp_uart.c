/**
  ******************************************************************************
  * @file    bsp_uart.c
  * @brief   调试串口驱动的实现
  ******************************************************************************
  * 详细说明见 bsp_uart.h 的文件头注释。
  ******************************************************************************
  */
#include "bsp_uart.h"
#include "usart.h"
#include <string.h>

/* 环形缓冲区大小（必须是 2 的幂，方便用位运算取余） */
#define UART_RX_BUF_SIZE  256U

/* 环形缓冲区：中断往里写（wr），主循环往外读（rd） */
static volatile uint8_t  s_rx_buf[UART_RX_BUF_SIZE];
static volatile uint16_t s_rx_wr;
static volatile uint16_t s_rx_rd;

/* HAL 中断接收需要的单字节暂存 */
static uint8_t s_rx_byte;

/*============================ printf 重定向 ============================*/
/*
 * 下面这段是 Keil 环境下 printf 重定向的标准写法：
 * - 勾选了 MicroLIB 时只需要 fputc；
 * - 没勾 MicroLIB 时还要关掉"半主机模式"并补几个桩函数，
 *   否则程序会卡死在启动阶段。
 * 两种情况这里都兼容了，不用关心细节。
 */
#if !defined(__MICROLIB)
#if (__ARMCC_VERSION >= 6010050) /* AC6 编译器 */
__asm(".global __use_no_semihosting");
#else                            /* AC5 编译器 */
#pragma import(__use_no_semihosting)
#endif

struct __FILE
{
    int handle;
};
FILE __stdout;

void _sys_exit(int x)
{
    (void)x;
    while (1)
    {
    }
}

void _ttywrch(int ch)
{
    (void)ch;
}
#endif /* !__MICROLIB */

/* printf 最终会一个字符一个字符地调用这里 */
int fputc(int ch, FILE *f)
{
    (void)f;
    /* 等待发送数据寄存器空，再写入要发的字符 */
    while ((USART1->SR & USART_SR_TXE) == 0U)
    {
    }
    USART1->DR = (uint8_t)ch;
    return ch;
}

/*============================ 初始化与接收 ============================*/
void BSP_UART_Init(void)
{
    s_rx_wr = 0U;
    s_rx_rd = 0U;

    /* 使能串口中断，并启动第一次"接收1个字节"的中断接收 */
    HAL_NVIC_SetPriority(USART1_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
    HAL_UART_Receive_IT(&huart1, &s_rx_byte, 1U);
}

/**
  * HAL 库的接收完成回调（弱函数，收满 1 字节进一次）。
  * 把收到的字节放进环形缓冲区，然后立刻启动下一次接收。
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        uint16_t next = (uint16_t)((s_rx_wr + 1U) & (UART_RX_BUF_SIZE - 1U));

        if (next != s_rx_rd) /* 缓冲区没满才存，满了就丢弃最新字节 */
        {
            s_rx_buf[s_rx_wr] = s_rx_byte;
            s_rx_wr = next;
        }

        HAL_UART_Receive_IT(&huart1, &s_rx_byte, 1U);
    }
}

/**
  * HAL 库的错误回调：出现过载(ORE)等错误时 HAL 会停止接收，
  * 这里清理错误后重新启动，防止串口"收着收着没反应了"。
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        HAL_UART_Receive_IT(&huart1, &s_rx_byte, 1U);
    }
}

uint8_t BSP_UART_GetByte(uint8_t *byte)
{
    if (byte == NULL)
    {
        return 0U;
    }

    if (s_rx_rd == s_rx_wr)
    {
        return 0U; /* 缓冲区空 */
    }

    *byte = s_rx_buf[s_rx_rd];
    s_rx_rd = (uint16_t)((s_rx_rd + 1U) & (UART_RX_BUF_SIZE - 1U));
    return 1U;
}

uint8_t BSP_UART_GetLine(char *buf, uint16_t buf_size)
{
    static char     s_line[UART_RX_BUF_SIZE]; /* 正在拼装的一行 */
    static uint16_t s_line_len = 0U;

    if ((buf == NULL) || (buf_size < 2U))
    {
        return 0U;
    }

    /* 把环形缓冲区里已有的字节都取出来拼装 */
    while (s_rx_rd != s_rx_wr)
    {
        char c = (char)s_rx_buf[s_rx_rd];
        s_rx_rd = (uint16_t)((s_rx_rd + 1U) & (UART_RX_BUF_SIZE - 1U));

        if ((c == '\r') || (c == '\n'))
        {
            if (s_line_len == 0U)
            {
                continue; /* 忽略空行（比如 \r\n 连发造成的） */
            }

            /* 一行结束：拷贝给调用者 */
            if (s_line_len >= buf_size)
            {
                s_line_len = (uint16_t)(buf_size - 1U); /* 超长截断 */
            }
            memcpy(buf, s_line, s_line_len);
            buf[s_line_len] = '\0';
            s_line_len = 0U;
            return 1U;
        }

        if (s_line_len < (UART_RX_BUF_SIZE - 1U))
        {
            s_line[s_line_len++] = c;
        }
    }

    return 0U; /* 还没收到完整的一行 */
}

void BSP_UART_SendBytes(const uint8_t *data, uint16_t len)
{
    uint16_t i;

    if (data == NULL)
    {
        return;
    }

    for (i = 0U; i < len; i++)
    {
        while ((USART1->SR & USART_SR_TXE) == 0U)
        {
        }
        USART1->DR = data[i];
    }
}
