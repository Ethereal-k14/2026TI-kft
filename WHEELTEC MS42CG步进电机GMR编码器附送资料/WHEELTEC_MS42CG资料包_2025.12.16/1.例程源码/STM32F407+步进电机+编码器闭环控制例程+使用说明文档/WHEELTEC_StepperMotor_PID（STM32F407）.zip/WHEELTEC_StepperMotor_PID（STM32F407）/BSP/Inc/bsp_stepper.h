/**
  ******************************************************************************
  * @file    bsp_stepper.h
  * @brief   D36A 步进驱动器脉冲输出驱动（TIM8 双通道，支持指定步数自动停止）
  ******************************************************************************
  * 工作原理（新手必读）：
  *
  * 1. D36A 是"脉冲+方向"型驱动器：
  *    - STEP 引脚每来一个上升沿，电机就转一个细分步；
  *    - DIR  引脚的电平决定转动方向。
  *
  * 2. 本驱动用 TIM8 的"输出比较-翻转模式"产生脉冲：
  *    - TIM8 以 100kHz 频率计数（每 10us 加 1）；
  *    - 每当计数值追上比较寄存器 CCR 时，引脚电平自动翻转一次，并进入中断；
  *    - 在中断里把 CCR 往后推一个"半周期"，如此往复就得到方波；
  *    - 翻转 2 次 = 1 个完整脉冲，所以发 N 步需要翻转 2N 次；
  *    - 翻转次数够了就关掉该通道 —— 这就实现了"发固定步数后自动停"。
  *
  * 3. 相比"PWM模式+数脉冲"，这种方式的优点是两个轴可以用同一个定时器
  *    输出互不相干的频率和步数（CCR1 管轴1，CCR2 管轴2）。
  ******************************************************************************
  */
#ifndef __BSP_STEPPER_H
#define __BSP_STEPPER_H

#include <stdint.h>
#include "main.h"

/* TIM8 计数频率 100kHz。1 步 = 2 次翻转，所以脉冲频率范围是 1 ~ 5000 Hz */
#define STEPPER_TIMER_TICK_HZ    100000U
#define STEPPER_MIN_FREQ_HZ           1U
#define STEPPER_MAX_FREQ_HZ        5000U

/* 轴编号：轴1 = STEP:PC6 / DIR:PC8，轴2 = STEP:PC7 / DIR:PC9 */
typedef enum
{
    STEPPER_AXIS_1 = 0,
    STEPPER_AXIS_2 = 1
} StepperAxis_t;

/* 初始化（在 MX_TIM8_Init 之后调用一次）。初始化后电机不会动 */
void Stepper_Init(void);

/* 设置方向电平。电机运行中不允许改方向，会返回 HAL_BUSY */
HAL_StatusTypeDef Stepper_SetDirection(StepperAxis_t axis,
                                       GPIO_PinState direction);
GPIO_PinState Stepper_GetDirection(StepperAxis_t axis);

/**
  * 启动一段脉冲：发 steps 个脉冲，频率 frequency_hz，发完自动停。
  * 立即返回不等待。该轴还没发完时再次调用会返回 HAL_BUSY。
  */
HAL_StatusTypeDef Stepper_Start(StepperAxis_t axis,
                                uint32_t steps,
                                uint32_t frequency_hz);

/**
  * 给正在运行的脉冲串"续杯"：追加 steps 个脉冲并把频率更新为
  * frequency_hz，新旧脉冲无缝衔接（用于连续旋转）。
  * 该轴空闲时等效于 Stepper_Start()。
  * 注意：运行中不允许换方向，要换向请先 Stop 再 SetDirection。
  */
HAL_StatusTypeDef Stepper_Feed(StepperAxis_t axis,
                               uint32_t steps,
                               uint32_t frequency_hz);

/* 立即停止 */
void Stepper_Stop(StepperAxis_t axis);
void Stepper_StopAll(void);

/* 该轴是否还在发脉冲（1=忙）*/
uint8_t Stepper_IsBusy(StepperAxis_t axis);

/* 查询剩余未发完的步数 */
uint32_t Stepper_GetRemainingSteps(StepperAxis_t axis);

/* 给 TIM8_CC_IRQHandler 调用的中断处理函数，应用代码不要调用 */
void Stepper_TIM8_CC_IRQHandler(void);

#endif /* __BSP_STEPPER_H */
